﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrjWinCsProjetSession
{
   public static class clsSourceDeDonnee
    {
      public static List<clsPays> GetTousLesPays()
        {
            
            List<clsPays> TousLesPays = new List<clsPays>();
            StreamReader monfichier = new StreamReader("pays.txt");
            while (monfichier.EndOfStream == false)
            {
                string nom = monfichier.ReadLine();
                string monnaie = monfichier.ReadLine();
                Single Valeur = Convert.ToSingle(monfichier.ReadLine());

               


                clsPays Unpays = new clsPays(nom, monnaie, Valeur);
                TousLesPays.Add(Unpays);

            }
            monfichier.Close();
            return TousLesPays;
        }
        public static void SaveTousLesPays(List<clsPays> TousLesPays)
        {
           
            StreamWriter monfichier = new StreamWriter("pays.txt");
            string TextAll = "";
            foreach (clsPays p in TousLesPays)
            {
                TextAll += p.Nom + "\n";
                TextAll += p.Monnaie+ "\n";
                TextAll += p.Valeur + "\n";
            }
            monfichier.Write(TextAll);
            monfichier.Close();

        }
        
}
}