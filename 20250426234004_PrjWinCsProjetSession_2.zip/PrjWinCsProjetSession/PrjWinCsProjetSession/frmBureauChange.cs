﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrjWinCsProjetSession
{
    public partial class frmBureauChange : Form
    {
        private bool clickBonus;


 
        //declaration de la structure
        
        //declaration de la collection
        List<clsPays> Touslespays = clsSourceDeDonnee.GetTousLesPays();
        //declaration des variables globales
        int indiceCourant;

        public bool ClickBonus { get => clickBonus; set => clickBonus = value; }

        public frmBureauChange()
        {
            InitializeComponent();
        }

        private void frmBureauChange_Load(object sender, EventArgs e)
        {
         
           
            //remplir le combo box au demarrage
            RemplirCombo();

            if (ClickBonus==false)
            {
                cboArrivee.Visible = false;
            }

            if (Touslespays.Count == 0)
            {
                cboChoix.Enabled = false;
                radconvert2.Enabled = radconvert1.Enabled = false;
                txtMontant.Enabled = false;
                btnconversion.Visible = false;
                return;
            }

            string[] jours = { "Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi" };
            int date = (int)DateTime.Today.DayOfWeek;

            lblD.Text = "Montreal, Aujourd'hui " + jours[date] + DateTime.Today.ToLongDateString();
           
            //checker un radio bouton au demarrage
            radconvert1.Checked = true;
            cboChoix.SelectedIndex = 0;
            cboArrivee.SelectedIndex = 0;

            radconvert2.Visible = radconvert1.Visible = true;

           

        }
        
       
      
        private void RemplirCombo()
        {
            //vider le combo box
            cboChoix.Items.Clear();
            cboArrivee.Items.Clear();
            //boucler dans la collection pour remplir le combo box
           foreach(clsPays p in Touslespays)
            {
                cboChoix.Items.Add(p.Nom + "-" + p.Monnaie);
                cboArrivee.Items.Add(p.Nom + "-" + p.Monnaie);
            }
            
        }
        

        private void cboChoix_SelectedIndexChanged(object sender, EventArgs e)
        {
            //recuperier le pays qui a ete selectionné et donne toutes ses informations
            Single Convers;
            indiceCourant = cboChoix.Items.IndexOf(cboChoix.SelectedItem);
            Convers =Touslespays[indiceCourant].Valeur;
            string devises = Touslespays[indiceCourant].Monnaie;
            //conversion d'une devise en CAD
            Convers = (1 / Convers);
            
 
            //si un pays a été selectionné ca affiche ses informations
            if(cboChoix.SelectedItem != null)
            {
               
                lblCan.Text = "   1 CAD.Dollar =" + Convers.ToString("F2") + Touslespays[indiceCourant].Monnaie;
                lblAutre.Text = "1" + Touslespays[indiceCourant].Monnaie + "=" + Touslespays[indiceCourant].Valeur  + "CAD.Dollar";
                radconvert1.Text = "CAD Dollar vers" + Touslespays[indiceCourant].Monnaie;
                radconvert2.Text = Touslespays[indiceCourant].Monnaie + "vers CAD.Dollar";  
                
            }
            if (ClickBonus == true)
            {
                if (cboArrivee.SelectedItem != null)
                {
                    // récupérer  la devise d'arrivée
                    int indiceArrivee = cboArrivee.SelectedIndex;
                    Single valeurDepart = Touslespays[indiceCourant].Valeur;
                    Single valeurArrivee = Touslespays[indiceArrivee].Valeur;

                    float tauxConversion = valeurArrivee / valeurDepart;
                    lblCan.Text = "1 " + Touslespays[indiceCourant].Monnaie + " = " + tauxConversion.ToString("F2") + " " + Touslespays[indiceArrivee].Monnaie;
                    lblAutre.Text = "1 " + Touslespays[indiceArrivee].Monnaie + " = " + (1 / tauxConversion).ToString("F2") + " " + Touslespays[indiceCourant].Monnaie;
                    radconvert1.Text = Touslespays[indiceCourant].Monnaie + " vers " + Touslespays[indiceArrivee].Monnaie;
                    radconvert2.Text = Touslespays[indiceArrivee].Monnaie + " vers " + Touslespays[indiceCourant].Monnaie;
                }
            }
        


    }

        private void radconvert1_CheckedChanged(object sender, EventArgs e)
        {
            if (radconvert1.Checked==true)
            {
                if (cboChoix.SelectedItem != null )
                {

                //si le premier radiobouton a été selectionnée on  convertis le dollar canadien en devises du pays selectionné
                 
                
                string devises = Touslespays[indiceCourant].Monnaie;
               
                lblconvert.Text = "CAN.dollar";

                }
                else
                {
                    if (cboArrivee.SelectedIndex != null)//si le deuxieme radiobouton a ete selectionne on convertis le pays de depart en devise de d'arrivee
                    {
                        string devisesDepart = Touslespays[indiceCourant].Monnaie;
                        lblconvert.Text = devisesDepart;
                    }
                }


            }
        }

        private void radconvert2_CheckedChanged(object sender, EventArgs e)

        {  //si le deuxieme radiobouton a été selectionnée on  convertis la devise du pays selectionné en dollard canadien 
            if (radconvert2.Checked == true)
            {

       
            if (cboChoix.SelectedItem != null)
            {
                    if (clickBonus == false)
                    {
                        Single valeur = Touslespays[indiceCourant].Valeur;
                        string devises = Touslespays[indiceCourant].Monnaie;

                        lblconvert.Text = devises;
                    }
                    else
                    {
                        if (cboArrivee.SelectedIndex != null)////si le deuxieme radiobouton a été selectionnée on  convertis la devise du  pays d'Arrivee en pays de depart
                        {
                            int indiceArrivee = cboArrivee.SelectedIndex;
                            string devisesArrivee = Touslespays[indiceArrivee].Monnaie;
                            lblconvert.Text = devisesArrivee;
                        }
                    }

             
            }
                
           
            }
        }

        private void btnconversion_Click(object sender, EventArgs e)
        {
            if (cboChoix.SelectedItem != null)
            {

         
            //convertir la valeur du Montant lorsque on clique sur le bouton convertir
           
            Single Conversion;
            
             Single valeur = Touslespays[indiceCourant].Valeur;

             String devises = Touslespays[indiceCourant].Monnaie;
           //verifier si le montant est vide
             if (txtMontant.Text == "")
            {
                MessageBox.Show("Veuillez saisir un montant svp ,saisi incorect");
                return;

            }
            Single Montant = Convert.ToSingle(txtMontant.Text);



            if (radconvert1.Checked )
            {
                //si c'est rad1 qui est checké on doit convertir le montant du dollar canadien en deises du pays selectionné
                Conversion = Montant/valeur;
                lblvers.Text = Conversion.ToString("F2") + devises;//F2 pour afficher uniquement deux chiffres après la vrgule
            }
            else
            { 
                //sinon faire l'inverse
            
                Conversion = Montant * valeur;
                lblvers.Text = Conversion.ToString("F2") + " CAN.Dollar ";
            }
            }
            else
            {
                if (ClickBonus)
                {
                    //  convertir n'importe quelle devise vers n'importe quelle autre
                    int indiceDepart = cboChoix.SelectedIndex;
                    int indiceArrivee = cboArrivee.SelectedIndex;
                    Single Montant = Convert.ToSingle(txtMontant.Text);

                    if (indiceDepart < 0 || indiceArrivee < 0)
                    {
                        MessageBox.Show("Veuillez choisir deux devises");
                        return;
                    }

                    Single valeurDepart = Touslespays[indiceDepart].Valeur; //premiere valeur qui est  selectionne dans cbochoix
                    Single valeurArrivee = Touslespays[indiceArrivee].Valeur; //valeur selectionne dans le deuxieme combobox

                    Single tauxConversion = valeurArrivee / valeurDepart;
                    Single montantConverti = Montant * tauxConversion;

                    lblvers.Text = montantConverti.ToString("F2") + " " + Touslespays[indiceArrivee].Monnaie;
                }
            }



    }


    private void btnRecommencer_Click(object sender, EventArgs e)//permettre à l'utilisateur de recommencer lorsqu'il a peut-etre fait une mauvaise saisi
        {
            string Titre = "Recommencer";
            String Message = "etes-vous sure de vouloir recommencer?";
            if (MessageBox.Show(Message, Titre, MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
               
                cboChoix.SelectedItem = "";
                txtMontant.Text = "";
                radconvert1.Checked = true;
                lblChoix.Text = "";
                lblconvert.Text = "";
                lblvers.Text = "";

                cboChoix.Focus();
                    
            }

         }
            

        private void btnFermer_Click(object sender, EventArgs e)
        {
            //pour fermer la session
            string Titre = "Fermeture de la Session";
            string msg = "Etes-vous sur de vouloir Fermer cette session?";
            if (MessageBox.Show(msg, Titre, MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                this.Close();
            }
        }
        private void txtMontant_keypress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
            //autoriser uniquement des chiffres et virgule
            if (char.IsDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar == ',')
            {
                e.Handled = false;
            }
        }

    }
}




