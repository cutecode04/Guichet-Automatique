﻿namespace PrjWinCsProjetSession
{
    partial class frmBureauChange
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnFermer = new System.Windows.Forms.Button();
            this.btnRecommencer = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.lblvers = new System.Windows.Forms.Label();
            this.btnconversion = new System.Windows.Forms.Button();
            this.lblconvert = new System.Windows.Forms.Label();
            this.txtMontant = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.radconvert2 = new System.Windows.Forms.RadioButton();
            this.radconvert1 = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblAutre = new System.Windows.Forms.Label();
            this.lblCan = new System.Windows.Forms.Label();
            this.cboChoix = new System.Windows.Forms.ComboBox();
            this.lblChoix = new System.Windows.Forms.Label();
            this.lblD = new System.Windows.Forms.Label();
            this.cboArrivee = new System.Windows.Forms.ComboBox();
            this.groupBox1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Modern No. 20", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(553, 65);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(440, 41);
            this.label1.TabIndex = 0;
            this.label1.Text = "BANQUE DE TORONTO";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Modern No. 20", 22F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(470, 115);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(613, 45);
            this.label2.TabIndex = 1;
            this.label2.Text = "Bureau De changes International";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.groupBox1.Controls.Add(this.cboArrivee);
            this.groupBox1.Controls.Add(this.btnFermer);
            this.groupBox1.Controls.Add(this.btnRecommencer);
            this.groupBox1.Controls.Add(this.groupBox4);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.cboChoix);
            this.groupBox1.Controls.Add(this.lblChoix);
            this.groupBox1.Controls.Add(this.lblD);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(312, 176);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(918, 703);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Programme de change Avec Le Dollar Canadien";
            // 
            // btnFermer
            // 
            this.btnFermer.Location = new System.Drawing.Point(458, 620);
            this.btnFermer.Name = "btnFermer";
            this.btnFermer.Size = new System.Drawing.Size(223, 40);
            this.btnFermer.TabIndex = 7;
            this.btnFermer.Text = "Fermer";
            this.btnFermer.UseVisualStyleBackColor = true;
            this.btnFermer.Click += new System.EventHandler(this.btnFermer_Click);
            // 
            // btnRecommencer
            // 
            this.btnRecommencer.Location = new System.Drawing.Point(154, 620);
            this.btnRecommencer.Name = "btnRecommencer";
            this.btnRecommencer.Size = new System.Drawing.Size(224, 40);
            this.btnRecommencer.TabIndex = 6;
            this.btnRecommencer.Text = "Recommencer";
            this.btnRecommencer.UseVisualStyleBackColor = true;
            this.btnRecommencer.Click += new System.EventHandler(this.btnRecommencer_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.groupBox4.Controls.Add(this.lblvers);
            this.groupBox4.Controls.Add(this.btnconversion);
            this.groupBox4.Controls.Add(this.lblconvert);
            this.groupBox4.Controls.Add(this.txtMontant);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Location = new System.Drawing.Point(41, 397);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(833, 197);
            this.groupBox4.TabIndex = 5;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Apply the Conversion";
            // 
            // lblvers
            // 
            this.lblvers.AutoSize = true;
            this.lblvers.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblvers.Location = new System.Drawing.Point(394, 114);
            this.lblvers.Name = "lblvers";
            this.lblvers.Size = new System.Drawing.Size(0, 20);
            this.lblvers.TabIndex = 4;
            // 
            // btnconversion
            // 
            this.btnconversion.Location = new System.Drawing.Point(29, 94);
            this.btnconversion.Name = "btnconversion";
            this.btnconversion.Size = new System.Drawing.Size(148, 40);
            this.btnconversion.TabIndex = 3;
            this.btnconversion.Text = "Convertir >>";
            this.btnconversion.UseVisualStyleBackColor = true;
            this.btnconversion.Click += new System.EventHandler(this.btnconversion_Click);
            // 
            // lblconvert
            // 
            this.lblconvert.AutoSize = true;
            this.lblconvert.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblconvert.Location = new System.Drawing.Point(394, 42);
            this.lblconvert.Name = "lblconvert";
            this.lblconvert.Size = new System.Drawing.Size(0, 20);
            this.lblconvert.TabIndex = 2;
            // 
            // txtMontant
            // 
            this.txtMontant.ForeColor = System.Drawing.Color.Red;
            this.txtMontant.Location = new System.Drawing.Point(237, 36);
            this.txtMontant.Name = "txtMontant";
            this.txtMontant.Size = new System.Drawing.Size(110, 26);
            this.txtMontant.TabIndex = 1;
            this.txtMontant.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMontant_keypress);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(55, 42);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(157, 20);
            this.label5.TabIndex = 0;
            this.label5.Text = "Entrez le montant:";
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.groupBox3.Controls.Add(this.radconvert2);
            this.groupBox3.Controls.Add(this.radconvert1);
            this.groupBox3.Location = new System.Drawing.Point(41, 254);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(833, 103);
            this.groupBox3.TabIndex = 4;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Types de Conversion";
            // 
            // radconvert2
            // 
            this.radconvert2.AutoSize = true;
            this.radconvert2.ForeColor = System.Drawing.Color.Red;
            this.radconvert2.Location = new System.Drawing.Point(40, 66);
            this.radconvert2.Name = "radconvert2";
            this.radconvert2.Size = new System.Drawing.Size(21, 20);
            this.radconvert2.TabIndex = 1;
            this.radconvert2.TabStop = true;
            this.radconvert2.UseVisualStyleBackColor = true;
            this.radconvert2.CheckedChanged += new System.EventHandler(this.radconvert2_CheckedChanged);
            // 
            // radconvert1
            // 
            this.radconvert1.AutoSize = true;
            this.radconvert1.ForeColor = System.Drawing.Color.Red;
            this.radconvert1.Location = new System.Drawing.Point(40, 35);
            this.radconvert1.Name = "radconvert1";
            this.radconvert1.Size = new System.Drawing.Size(21, 20);
            this.radconvert1.TabIndex = 0;
            this.radconvert1.TabStop = true;
            this.radconvert1.UseVisualStyleBackColor = true;
            this.radconvert1.Visible = false;
            this.radconvert1.CheckedChanged += new System.EventHandler(this.radconvert1_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.groupBox2.Controls.Add(this.lblAutre);
            this.groupBox2.Controls.Add(this.lblCan);
            this.groupBox2.Location = new System.Drawing.Point(314, 115);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(560, 103);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Les Valeurs Actuelles";
            // 
            // lblAutre
            // 
            this.lblAutre.AutoSize = true;
            this.lblAutre.ForeColor = System.Drawing.Color.Red;
            this.lblAutre.Location = new System.Drawing.Point(44, 65);
            this.lblAutre.Name = "lblAutre";
            this.lblAutre.Size = new System.Drawing.Size(0, 20);
            this.lblAutre.TabIndex = 1;
            // 
            // lblCan
            // 
            this.lblCan.AutoSize = true;
            this.lblCan.ForeColor = System.Drawing.Color.Red;
            this.lblCan.Location = new System.Drawing.Point(35, 30);
            this.lblCan.Name = "lblCan";
            this.lblCan.Size = new System.Drawing.Size(0, 20);
            this.lblCan.TabIndex = 0;
            // 
            // cboChoix
            // 
            this.cboChoix.FormattingEnabled = true;
            this.cboChoix.Location = new System.Drawing.Point(70, 148);
            this.cboChoix.Name = "cboChoix";
            this.cboChoix.Size = new System.Drawing.Size(121, 28);
            this.cboChoix.TabIndex = 2;
            this.cboChoix.SelectedIndexChanged += new System.EventHandler(this.cboChoix_SelectedIndexChanged);
            // 
            // lblChoix
            // 
            this.lblChoix.AutoSize = true;
            this.lblChoix.Location = new System.Drawing.Point(66, 115);
            this.lblChoix.Name = "lblChoix";
            this.lblChoix.Size = new System.Drawing.Size(155, 20);
            this.lblChoix.TabIndex = 1;
            this.lblChoix.Text = "Choisir Votre pays";
            // 
            // lblD
            // 
            this.lblD.AutoSize = true;
            this.lblD.Location = new System.Drawing.Point(92, 59);
            this.lblD.Name = "lblD";
            this.lblD.Size = new System.Drawing.Size(79, 20);
            this.lblD.TabIndex = 0;
            this.lblD.Text = "Montreal";
            // 
            // cboArrivee
            // 
            this.cboArrivee.FormattingEnabled = true;
            this.cboArrivee.Location = new System.Drawing.Point(70, 182);
            this.cboArrivee.Name = "cboArrivee";
            this.cboArrivee.Size = new System.Drawing.Size(121, 28);
            this.cboArrivee.TabIndex = 8;
           // this.cboArrivee.SelectedIndexChanged += new System.EventHandler(this.cboArrivee_SelectedIndexChanged);
            // 
            // frmBureauChange
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Green;
            this.ClientSize = new System.Drawing.Size(1448, 930);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "frmBureauChange";
            this.Text = "frmBureauChange";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmBureauChange_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblChoix;
        private System.Windows.Forms.Label lblD;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton radconvert2;
        private System.Windows.Forms.RadioButton radconvert1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox cboChoix;
        private System.Windows.Forms.Button btnFermer;
        private System.Windows.Forms.Button btnRecommencer;
        private System.Windows.Forms.Button btnconversion;
        private System.Windows.Forms.Label lblconvert;
        private System.Windows.Forms.TextBox txtMontant;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblvers;
        private System.Windows.Forms.Label lblAutre;
        private System.Windows.Forms.Label lblCan;
        private System.Windows.Forms.ComboBox cboArrivee;
    }
}