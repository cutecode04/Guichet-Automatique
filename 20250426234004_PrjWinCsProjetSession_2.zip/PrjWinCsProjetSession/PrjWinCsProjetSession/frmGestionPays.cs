﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrjWinCsProjetSession
{
    public partial class frmGestionPays : Form
    {
        //declaration de la structure
        
        //declaration de la collection
        List<clsPays> TousLespays = clsSourceDeDonnee.GetTousLesPays();
        clsBureau bureau = new clsBureau("12345BOM", "BANQUE DESJARDINS DELACONCORDE ", "Laval", "Ouvert");

        //declaration des variables globales
        int indiceCourant = 0;
        string methode="";
        public frmGestionPays()
        {
            InitializeComponent();
        }

        private void frmGestionPays_Load(object sender, EventArgs e)
        {
            clsSourceDeDonnee.GetTousLesPays();

           //verifier si la collection est vide au demarrage
            if (TousLespays.Count == 0)
            {
                txtNom.Text = "vide";
                txtValeur.Text = "vide";
                txtdevise.Text = "vide";
                //autoriser uniquement la lecture mais pas la saisi,mettre le texte en rouge et le background en blanc
                txtNom.ReadOnly = true;
                txtNom.ForeColor = Color.Red;
                txtNom.BackColor = Color.White;
                txtValeur.ReadOnly = true;
                txtValeur.ForeColor = Color.Red;
                txtValeur.BackColor = Color.White;
                txtdevise.ReadOnly = true;
                txtdevise.ForeColor = Color.Red;
                txtdevise.BackColor = Color.White;



                lblResultatPays.Text = "collection vide,veuillez ajouter un nouvel etudiant";
                
                btnAjouter.Focus();
            }
            //si c'Est pas vide ca affiche les informations du premier pays
            else
            {
                indiceCourant = 0;
                affichageCollection();
                RemplirPays();
                btnAjouter.Focus();
            }
            //affixher les boutona
            btnAnnuler.Visible = btnModifier.Visible = btnSauvegarder.Visible = btnSupprimer.Visible = false;
            btnAjouter.Visible = true;
            btnModifier.Visible = btnSupprimer.Visible = false;

        }
       
        
        private void affichageCollection()
        {
            int Pos1, Pos2;
            Pos1 = TousLespays[indiceCourant].Nom.IndexOf(" ");
            Pos2 = TousLespays[indiceCourant].Nom.IndexOf(" ", Pos1 + 1);
            if (Pos1 != -1 && Pos2 != -1)
            {
                string position1 = TousLespays[indiceCourant].Nom.Substring(0, 1).ToUpper() + TousLespays[indiceCourant].Nom.Substring(1, Pos2).ToLower();

                string position2 = TousLespays[indiceCourant].Nom.Substring(Pos2 + 1, 1).ToUpper() + TousLespays[indiceCourant].Nom.Substring(Pos2 + 2).ToLower();

                TousLespays[indiceCourant].Nom = position1 + " " + position2;
            }
            else if (Pos1 != -1)
            {
                TousLespays[indiceCourant].Nom = TousLespays[indiceCourant].Nom.Substring(0, 1).ToUpper() + TousLespays[indiceCourant].Nom.Substring(1, Pos1).ToLower() + " " + TousLespays[indiceCourant].Nom.Substring(Pos1 + 1, 1).ToUpper() + TousLespays[indiceCourant].Nom.Substring(Pos1 + 2).ToLower();
            }
            else
            {
                TousLespays[indiceCourant].Nom = TousLespays[indiceCourant].Nom.Substring(0, 1).ToUpper() + TousLespays[indiceCourant].Nom.Substring(1).ToLower();
            }

            Pos1 = TousLespays[indiceCourant].Monnaie.IndexOf(".");
            if (Pos1 != -1)
            {
                string position1 = TousLespays[indiceCourant].Monnaie.Substring(0, Pos1).ToUpper();
                string position2 = TousLespays[indiceCourant].Monnaie.Substring(Pos1 + 1).Trim();
                position2 = position2.Substring(0, 1).ToUpper() + position2.Substring(1).ToLower();
                TousLespays[indiceCourant].Monnaie = position1 + "." + position2;
            }
            else
            {
                TousLespays[indiceCourant].Monnaie = TousLespays[indiceCourant].Monnaie.Substring(0, 1).ToUpper() + TousLespays[indiceCourant].Monnaie.Substring(1).ToLower();
            }
            //afficher les infos des pays
            txtNom.Text = TousLespays[indiceCourant].Nom;
            txtdevise.Text = TousLespays[indiceCourant].Monnaie;
            txtValeur.Text = TousLespays[indiceCourant].Valeur.ToString();
            //afficher la position du pays
            lblResultatPays.Text =   "                     Pays " + (indiceCourant + 1) + " sur un total de " + TousLespays.Count    ;
            txtNom.ReadOnly = true;
            txtNom.ForeColor = Color.Red;
            txtNom.BackColor = Color.White;

            txtValeur.ReadOnly = true;
            txtValeur.ForeColor = Color.Red;
            txtValeur.BackColor = Color.White;


            txtdevise.ReadOnly = true;
            txtdevise.ForeColor = Color.Red;
            txtdevise.BackColor = Color.White;

        }
      
            private void RemplirPays()

            
        {
            //vider la liste
            lstChoix.Items.Clear();
            foreach(clsPays Mondial in TousLespays)
            {
                //ajouter les pays dans la listes
                lstChoix.Items.Add(Mondial.Nom);
            }
        }

        private void btnAjouter_Click_1(object sender, EventArgs e)
        {
            txtNom.ReadOnly = false;
            txtValeur.ReadOnly = false;
            txtdevise.ReadOnly = false;
            //supprimer apres avoir fini d'Ajouter dans le txt
            txtNom.Clear();
            txtValeur.Clear();
            txtdevise.Clear();

            methode = "Ajout";
            txtNom.Text = txtValeur.Text = txtdevise.Text = "";
            txtNom.Focus();
            lblResultatPays.Text = " ---------------EN MODE AJOUT------------------       ";
            //cacher et montrer les boutons
            btnSupprimer.Visible =  false;
            btnAjouter.Visible = false;
            btnSauvegarder.Visible = true;
            btnAnnuler.Visible = true;
            btnModifier.Visible = false;
            btnAjouter.Focus();

        }

        private void btnSauvegarder_Click_1(object sender, EventArgs e)
        {
             int PostV;int postP;
            
          
            //verifier si le pays est vide
            if (txtNom.Text.Length== 0)
            {
                MessageBox.Show("Desolé Nom vide,Impossible de sauvegarder");
                return;
            }
            //verifier si la devises est vide
            if (txtdevise.Text.Length==0)
            {
                MessageBox.Show("Desolé devise vide,Impossible de sauvegarder");
                return;
            }
            //verifier si la valeur est vide
            if (txtValeur.Text.Length == 0)
            {
                MessageBox.Show("Desolé valeur vide,Impossible de sauvegarder");
                return;
            }
            //chercher la position de la virgule dans la valeur

            PostV = txtValeur.Text.IndexOf(",");
            //verifier si la virgule existes au debut et a la fin
            if (PostV != -1)
            {
                if (txtValeur.Text.Substring(0,PostV).Length==0)
                {
                    MessageBox.Show("Sasi incorrecte,la virgule ne peux pas etre au debut", "virgule mal entrée");
                    return;
                }
                if (txtValeur.Text.Substring(PostV + 1).Length == 0)
                {
                    MessageBox.Show("Sasi incorrecte,la virgule ne peux pas etre à la fin", "virgule mal entrée");
                    return;
                }
            }
            postP = txtdevise.Text.IndexOf(".");
                if(postP!=-1){
                if (txtdevise.Text.Substring(0, postP).Length == 0)
                {
                    MessageBox.Show("Sasi incorrecte,le point  ne peux pas etre au debut", "point mal entrée");
                    return;
                }
                if (txtdevise.Text.Substring(postP+1).Length == 0)
                {
                    MessageBox.Show("Sasi incorrecte,le point ne peux pas etre à la fin", "point mal entrée");
                    return;
                }

            }


            string Nom = txtNom.Text;
            Single valeur = Convert.ToSingle(txtValeur.Text);
            string devises = txtdevise.Text;

            bureau.Pays = TousLespays;

            if (methode == "Ajout")
            {
                //verifier si un pays ajouter et ne pas permettre de ne pas etre rajouter une deuxieme fois
               
                    if (bureau.TrouverPays(Nom).Nom == Nom )
                    {
                        MessageBox.Show("Impossible d'Ajouter un pays deux fois", "pays existant");
                        return;
                    }
                
                TousLespays.Add(new clsPays(Nom, devises, valeur));
                indiceCourant = TousLespays.Count - 1;
                btnAjouter.Focus();
                clsSourceDeDonnee.SaveTousLesPays(TousLespays);
                
            }
             if (methode == "Modification")
            {
                //verifier si un pays a deja ete modifier et ne pas permettre de ne pas etre rajouter une deuxieme fois
               
                    if (bureau.TrouverPays(Nom).Nom == Nom && bureau.TrouverPays(Nom).Nom != lstChoix.SelectedItem.ToString())
                    {
                        MessageBox.Show("Impossible d'Ajouter un pays deux fois", "pays existant");
                        return;
                    }

                TousLespays[indiceCourant].Creer(Nom, devises, valeur);

               
            }
            affichageCollection();
            btnModifier.Visible = btnSupprimer.Visible = true;
            btnSauvegarder.Visible = btnAnnuler.Visible = false;
            btnAjouter.Visible = true;
            RemplirPays();


        }

        private void lstChoix_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            //verifier quand l'utilisateur clique sur la liste mais ne selectionne rien
            if (lstChoix.SelectedItem == null)  return;
            string PaysChoisi = lstChoix.SelectedItem.ToString();
              indiceCourant = lstChoix.Items.IndexOf(PaysChoisi);
                affichageCollection();
                
            btnAjouter.Visible = true;
            btnModifier.Visible = btnSauvegarder.Visible = btnModifier.Visible = btnSupprimer.Visible = true;
            btnAnnuler.Visible = false;


        }
        
        //pour pouvoir modifier les informations d'un pays
        private void btnModifier_Click_1(object sender, EventArgs e)
        {

            txtNom.ReadOnly = false;
            txtValeur.ReadOnly = false;
            txtdevise.ReadOnly = false;
            methode = "Modification";
            txtNom.Focus();
            lblResultatPays.Text = "-------------EN MODE MODIFICATION----------------";
            btnModifier.Visible = btnSupprimer.Visible = false;
            btnAjouter.Visible = false;
            btnSauvegarder.Visible = btnAnnuler.Visible = true;
        }

        private void btnSupprimer_Click_1(object sender, EventArgs e)
        {
            string Titre = "Suppression d'un etudiant";
            String Message = "etes-vous sure de vouloir supprimer?";
            if (MessageBox.Show(Message, Titre, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)

            {
                //supprimer dans la collection
                indiceCourant = lstChoix.Items.IndexOf(lstChoix.SelectedItem);
                TousLespays.RemoveAt(indiceCourant);

                RemplirPays();
                //aller au precedent pays apres la suppression d'un pays
                if (TousLespays.Count != 0){
                    
                    RetourEnarriere();
                    clsSourceDeDonnee.SaveTousLesPays(TousLespays);
                  
                }
                //mais si c'Est vide il ne peut pas supprimer
                else
                {
                    txtNom.Text = "Vide";
                    txtValeur.Text = "vide";
                    txtdevise.Text = "vide";
                    lblResultatPays.Text = "La collection est vide,veuillez ajouter un nouveau pays";
                    btnAnnuler.Visible = btnModifier.Visible = btnSauvegarder.Visible = btnSupprimer.Visible = false;
                    btnAjouter.Focus();
                    RemplirPays();
                    clsSourceDeDonnee.SaveTousLesPays(TousLespays);
                }
            }
        }
        //fonction pour retourner en arriere apres la suppression d'un pays
        private void RetourEnarriere()
        {
            indiceCourant -= 1;
            if (indiceCourant <0) indiceCourant = 0;

            affichageCollection();
          

        }
        
        private void btnAnnuler_Click_1(object sender, EventArgs e)
            //cette methode est utiliser dans ajouter,suprimer,sauvegarder ou modifier quand l'utilisateur ne veut plus faire l'Action
        {
            affichageCollection();
            btnAjouter.Visible = true;

            btnSauvegarder.Visible = false;
            btnAnnuler.Visible = false;

        }

        private void txtValeur_KeyPress(object sender, KeyPressEventArgs e)
        {
            //autoriser uniquement les chiffres,la virgule, les espacez et bloquer tout autres caractères
            e.Handled = true;
            if (char.IsDigit(e.KeyChar) || char.IsControl(e.KeyChar) || e.KeyChar ==',')
            {
                e.Handled = false;
            }
        }

        private void txtdevises_keypress(object sender, KeyPressEventArgs e)
        {
           //autoriser uniquement les lettres,les espaces,les points et bloquer les autres espaces
            e.Handled = true;
            if(char.IsLetter(e.KeyChar)|| char.IsControl(e.KeyChar)|| e.KeyChar=='.'|| char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = false;
            }
        }

        private void txtNom_keypress(object sender, KeyPressEventArgs e)
        {
            //autoriser uniquement les lettres,les espaces,les points et bloquer les autres espaces

            if (char.IsLetter(e.KeyChar) || char.IsControl(e.KeyChar) || char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }
    }
}
