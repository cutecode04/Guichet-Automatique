﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrjWinCsProjetSession
{
   public class clsPays
    {
        private string nom;
        private string monnaie;
        private Single valeur;

        public string Nom { get => nom; set => nom=value; }
        public string Monnaie { get => monnaie; set => monnaie = value; }
        public float Valeur { get => valeur; set => valeur = value; }

        public clsPays()
        {
            nom = "vide";
            monnaie = "vide";
            valeur = 0;
        }
        public clsPays(string Nom, string Monnaie, float Valeur)
        {
            this.Nom = Nom;
            this.Monnaie = Monnaie;
            this.Valeur = Valeur;
        }

        public clsPays Creer(string Nom,string Monnaie, float valeur)
        {

            return new clsPays(Nom, Monnaie, valeur);

        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="Montant">Montant à convertir soit en CAD ou autre devise</param>
        /// <param name="chekCAD">Boolean qui Verifie s'il faut convertir en CAD ou autre devise</param>
        /// <returns>Le resultat de ka conversion en CAD ou autre devise</returns>
        public Single GetValeurCanada(Single Montant, bool chekCAD)
        {
            if (chekCAD)
            {
                return Montant*valeur;
            }
            else
            {
                return Montant/valeur;
            }
        }
        public void Afficher()
        {
            string info = Nom + "-" + Monnaie + "-" + Valeur;
          
        }
    }
}
