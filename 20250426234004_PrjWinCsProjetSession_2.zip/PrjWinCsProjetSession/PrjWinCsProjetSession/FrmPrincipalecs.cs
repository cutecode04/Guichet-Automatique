﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrjWinCsProjetSession
{
    public partial class FrmPrincipalecs : Form
    {
        public FrmPrincipalecs()
        {
            InitializeComponent();
        }

       

        private void bureauDeChangeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form childrenExist = null;

            foreach (var child in this.MdiChildren)
            {
                if (child is frmBureauChange)
                {
                    childrenExist = child;
                    break;
                }
            }

            if (childrenExist == null)
            {
                frmBureauChange bureauDechange = new frmBureauChange();
                bureauDechange.MdiParent = this;
                bureauDechange.ClickBonus = false;
                bureauDechange.Show();
            }
           

           
        }

        private void gestionDesPaysToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form childrenExist = null;

            foreach(var child in this.MdiChildren)
            {
                if(child is frmGestionPays)
                {
                    childrenExist = child;
                    break;
                }
            }

            if (childrenExist == null)
            {
                frmGestionPays gestionPays = new frmGestionPays();
                gestionPays.MdiParent = this;
                gestionPays.Show();
            }

        }

        private void quitterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string Titre = "Fermeture de l'application";
            string msg = "Etes-vous sur de vouloir quitter ce programme ?";
            if (MessageBox.Show(msg, Titre, MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void bonusToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form childrenExist = null;

            foreach (var child in this.MdiChildren)
            {
                if (child is frmBureauChange)
                {
                    childrenExist = child;
                    break;
                }
            }

            if (childrenExist == null)
            {
                frmBureauChange bureauDechange = new frmBureauChange();
                bureauDechange.MdiParent = this;
                bureauDechange.ClickBonus = true;
                bureauDechange.Show();
            }
          
        }
    }
}


