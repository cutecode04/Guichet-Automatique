﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrjWinCsProjetSession
{
 public class clsBureau
    {
        private string numero;
        private string nom;
        private string addresse;
        private List<clsPays>pays;
        private string statut;


        public clsBureau()
        {
             numero = "vide";
             nom = "vide";
            addresse = "vide";
            pays= new List<clsPays>();
            statut = "vide";
        }

        public clsBureau(string Numero, string Nom, string Addresse, List<clsPays> Pays, string Statut)
        {
            this.numero= Numero;
            this.nom = Nom;
            this.addresse = Addresse;
            this.pays = Pays;
            this.statut = Statut;
        }
        public clsBureau(string Numero, string Nom, string Addresse,  string Statut)
        {
            this.numero = Numero;
            this.nom = Nom;
            this.addresse = Addresse;
            pays = new List<clsPays>();
            this.statut = Statut;
        }



        public string Numero { get => numero; }
        public string Nom { get => nom; }
        public string Addresse { get => addresse; }
        public string Statut { get => statut; }
        internal List<clsPays> Pays{ get => pays; set => pays = value; }

        public void Creer(string nom,string numero,string statut,string addresse)
        {
            this.numero = numero;
            this.nom = nom;
            statut = "Ouvert";
            pays = new List<clsPays>();
            this.addresse=addresse;

        }
        public clsPays TrouverPays(string nomPays)
        {
            foreach(clsPays p in Pays)
            {
                if (p.Nom == nomPays)
                {
                    return p;
                }
              
            }return null;
        }
        public void Afficher()
        {
            string info = "Bureau :" + Nom + " numero : " + numero + " Statut: " + statut + " addresse: " + addresse + " pays : " + pays; 
            return;
        }
        public void Fermer(string numero)
        {
            this.numero = numero;
            statut = "Fermé";
        }
    }
}
